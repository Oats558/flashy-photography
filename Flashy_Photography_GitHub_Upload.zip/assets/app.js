function toggleMenu(){
  const nav = document.getElementById('mobileNav');
  if(!nav) return;
  nav.style.display = (nav.style.display === 'grid') ? 'none' : 'grid';
}

function setYear(){
  const el = document.getElementById('year');
  if(el) el.textContent = new Date().getFullYear();
}
setYear();

// Booking form demo (localStorage)
function getSaved(){
  try{
    return JSON.parse(localStorage.getItem('bookingRequests') || '[]');
  }catch(e){
    return [];
  }
}

function saveRequest(req){
  const all = getSaved();
  all.unshift(req);
  localStorage.setItem('bookingRequests', JSON.stringify(all));
}

function renderRequests(all){
  const wrap = document.getElementById('requests');
  if(!wrap) return;
  if(!all.length){
    wrap.innerHTML = '<p class="small muted">No saved requests yet.</p>';
    return;
  }
  wrap.innerHTML = all.map(r => `
    <div class="req-item">
      <p><strong>${r.type}</strong> — ${r.date}</p>
      <p class="muted small">${r.name} • ${r.email}</p>
      <p class="small">${r.notes || ''}</p>
    </div>
  `).join('');
}

window.loadRequests = function(){
  renderRequests(getSaved());
}

(function initBooking(){
  const form = document.getElementById('bookingForm');
  if(!form) return;

  const msg = document.getElementById('formMsg');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const req = {
      name: String(data.get('name') || '').trim(),
      email: String(data.get('email') || '').trim(),
      type: String(data.get('type') || '').trim(),
      date: String(data.get('date') || '').trim(),
      notes: String(data.get('notes') || '').trim(),
      createdAt: new Date().toISOString()
    };

    saveRequest(req);
    form.reset();
    if(msg) msg.textContent = 'Saved. Click "View Saved Requests" to confirm.';
  });
})();
